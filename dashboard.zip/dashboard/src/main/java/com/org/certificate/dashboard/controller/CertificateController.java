package com.org.certificate.dashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.org.certificate.dashboard.entity.Certificate;
import com.org.certificate.dashboard.entity.CertificateStats;
import com.org.certificate.dashboard.repository.CertificateStatsRepository;
import com.org.certificate.dashboard.repository.CustomCertificateStatsRepository;

@RestController
@RequestMapping("/certificate")
public class CertificateController {

	// @Autowired
	// CertificateRepository certificateRepository;
	@Autowired
	CertificateStatsRepository certificateStatsRepository;

	@Autowired

	CustomCertificateStatsRepository customCertificateStatsRepository;

	// fetch all certificate list from database
	@RequestMapping(value = "/allcertificate", method = RequestMethod.GET)
	public Iterable<Certificate> allCertificate() {
		return null;// certificateRepository.findAll();
	}

	// fetch all certificate list from database
	@RequestMapping(value = "/allStats", method = RequestMethod.GET)
	public Iterable<CertificateStats> allStats() {
		return certificateStatsRepository.findAll();
	}

	// fetch all certificate list from database
	//@RequestMapping(value = "/allStats/{expiryType}", method=RequestMethod.GET)
	@GetMapping("/allStats/{expiryType}")
	public CertificateStats getCertificateCount() {
		return customCertificateStatsRepository.findCertificateCountByExpiryTypeAndCertificateType(@PathVariable("expiryType") String expiryType);
	}

}
