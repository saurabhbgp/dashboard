package com.org.certificate.dashboard.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

//@Entity
//@Table(name = "tblcertificatedetails")
public class Certificate {
	private String customerName;
	private String serverName;
	private String certificateName;
	private String certificateExpiryDate;
	private String certificateType;
	private String certificateStatus;
	private String issueingAutority;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getCertificateName() {
		return certificateName;
	}

	public void setCertificateName(String certificateName) {
		this.certificateName = certificateName;
	}

	public String getCertificateExpiryDate() {
		return certificateExpiryDate;
	}

	public void setCertificateExpiryDate(String certificateExpiryDate) {
		this.certificateExpiryDate = certificateExpiryDate;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getCertificateStatus() {
		return certificateStatus;
	}

	public void setCertificateStatus(String certificateStatus) {
		this.certificateStatus = certificateStatus;
	}

	public String getIssueingAutority() {
		return issueingAutority;
	}

	public void setIssueingAutority(String issueingAutority) {
		this.issueingAutority = issueingAutority;
	}

	@Override
	public String toString() {
		return "ExpiredCertificate [customerName=" + customerName + ", serverName=" + serverName + ", certificateName="
				+ certificateName + ", certificateExpiryDate=" + certificateExpiryDate + ", certificateType="
				+ certificateType + ", certificateStatus=" + certificateStatus + ", issueingAutority="
				+ issueingAutority + "]";
	}

}
