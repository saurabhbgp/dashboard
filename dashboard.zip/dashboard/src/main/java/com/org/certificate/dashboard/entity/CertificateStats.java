package com.org.certificate.dashboard.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "tblcertificatestats", uniqueConstraints = {
		@UniqueConstraint(columnNames = { "expiryType", "certificateType" }) })
public class CertificateStats {

	@Id
	@Column(name = "expiryType")
	private String expiryType;

	@Column(name = "total")
	private int total;

	@Column(name = "certificateType")
	private String certificateType;

	@Column(name = "crCreated")
	private int crCreated;

	@Column(name = "crWIP")
	private int crWIP;

	@Column(name = "crApproved")
	private int crApproved;

	@Column(name = "crScheduled")
	private int crScheduled;

	@Transient
	private int F5Devices;

	@Transient
	private int SSL;

	public String getExpiryType() {
		return expiryType;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public int getCrCreated() {
		return crCreated;
	}

	public void setCrCreated(int crCreated) {
		this.crCreated = crCreated;
	}

	public int getCrWIP() {
		return crWIP;
	}

	public void setCrWIP(int crWIP) {
		this.crWIP = crWIP;
	}

	public int getCrApproved() {
		return crApproved;
	}

	public void setCrApproved(int crApproved) {
		this.crApproved = crApproved;
	}

	public int getCrScheduled() {
		return crScheduled;
	}

	public void setCrScheduled(int crScheduled) {
		this.crScheduled = crScheduled;
	}

	public void setExpiryType(String expiryType) {
		this.expiryType = expiryType;
	}

	public int getF5Devices() {
		return F5Devices;
	}

	public void setF5Devices(int f5Devices) {
		F5Devices = f5Devices;
	}

	public int getSSL() {
		return SSL;
	}

	public void setSSL(int sSL) {
		SSL = sSL;
	}

	@Override
	public String toString() {
		return "CertificateStats [expiryType=" + expiryType + ", total=" + total + ", certificateType="
				+ certificateType + ", crCreated=" + crCreated + ", crWIP=" + crWIP + ", crApproved=" + crApproved
				+ ", crScheduled=" + crScheduled + ", F5Devices=" + F5Devices + ", SSL=" + SSL + "]";
	}

}
