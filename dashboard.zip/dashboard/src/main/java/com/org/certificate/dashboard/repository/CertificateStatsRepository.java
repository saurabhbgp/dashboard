package com.org.certificate.dashboard.repository;

import org.springframework.data.repository.CrudRepository;

import com.org.certificate.dashboard.entity.CertificateStats;

public interface CertificateStatsRepository extends CrudRepository<CertificateStats, String> {

}
