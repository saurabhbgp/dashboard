package com.org.certificate.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.org.certificate.dashboard.entity.CertificateStats;

public interface CustomCertificateStatsRepository extends JpaRepository<CertificateStats, String> {
	//@Query(value = "SELECT * FROM Users u WHERE u.status = :expiryType and u.name = :certificateType", nativeQuery = true)
	@Query(value = "select t1.expiryType, t2.F5Device, t3.SSL, t4.crCreated,t5.crWIP,t6.crApproved,t7.crScheduled\r\n" + 
			"from (select count(expiryType) as \"expiryType\"  from tblcertificatestats where expiryType=:expiryType) as t1,\r\n" + 
			"(select count(certificateType) as \"F5Device\" from tblcertificatestats where expiryType=:expiryType and certificateType='F5Device') as t2,\r\n" + 
			"(select count(certificateType) as \"SSL\" from tblcertificatestats where expiryType=:expiryType and certificateType='SSL') as t3\r\n" + 
			"(select sum(crCreated) as \"crCreated\" from tblcertificatestats where expiryType=:expiryType) as t4,\r\n" + 
			"(select sum(crWIP) as \"crWIP\" from tblcertificatestats where expiryType=:expiryType) as t5,\r\n" + 
			"(select sum(crApproved) as \"crApproved\" from tblcertificatestats where expiryType=:expiryType) as t6,\r\n" + 
			"(select sum(crScheduled) as \"crScheduled\" from tblcertificatestats where expiryType=:expiryType) as t7", nativeQuery = true)
	CertificateStats findCertificateCountByExpiryTypeAndCertificateType(String expiryType);

}
